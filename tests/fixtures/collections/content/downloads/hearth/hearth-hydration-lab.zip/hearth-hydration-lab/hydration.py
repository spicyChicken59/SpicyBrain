import json
import sys


def hydration(recipe):
    starter_flour = recipe["starter"] / (1 + recipe["starterHydration"] / 100)
    flour = recipe["flour"] + starter_flour
    water = recipe["water"] + (recipe["starter"] - starter_flour)
    return {"flour": round(flour), "water": round(water), "hydration": round(100 * water / flour, 1)}


if __name__ == "__main__":
    with open(sys.argv[1], encoding="utf-8") as handle:
        print(json.dumps(hydration(json.load(handle))))
