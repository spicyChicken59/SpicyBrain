# Hydration lab (synthetic fixture)

Run `python hydration.py recipe.json` with Python 3.12. The script prints the
true hydration of the recipe, counting the flour and water inside the starter,
and compares it with `expected.json`.

These files belong to a non-production test fixture. No execution evidence is
claimed for them.
