# Larkfield café data pack (synthetic fixture)

`orders.csv` lists fictional weekend orders for the capstone. Every name,
quantity and date is invented for a non-production test fixture.
