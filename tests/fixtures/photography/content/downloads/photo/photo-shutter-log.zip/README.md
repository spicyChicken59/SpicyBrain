# Shutter log (synthetic fixture)

Fill shutter-log.csv while working the lab "Log shutter times against motion blur".
Movement during the exposure, in millimetres, is the speed in metres per second
multiplied by the shutter duration in seconds, times 1000. Mark each frame sharp
or blurred at the size you intend to show it.
